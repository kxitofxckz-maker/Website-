KXITO WEBSITE — QUICK START

Files:
- index.html : main page content
- style.css  : layout, colours, responsive/mobile design
- script.js  : mobile navigation and current year

Preview:
1. Extract the ZIP.
2. Open index.html in a browser.

Upload:
- Upload index.html, style.css, and script.js to the same folder on your static hosting service.
- Make sure index.html is in the public/root folder.

Before publishing:
- Change the placeholder contact email hello@kxito.example in index.html to your real contact/booking email.
- Replace the clearly marked sample testimonials with genuine customer reviews or remove that section.
- Update reading details, prices, policies, social links, and booking destination to match your real service.

This is a static front-end starter website. It does not include a payment system, customer database, or booking backend. Tarot-style content is framed for reflection/entertainment and does not promise predictions.
